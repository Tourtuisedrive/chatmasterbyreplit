# Modern Chatbot Interface

A modern, responsive chatbot interface built with Flask and vanilla JavaScript. The application features a clean, intuitive design with support for both light and dark themes.

## Features

- 💬 Real-time chat interface
- 🌓 Light/Dark theme support
- 💨 Smooth animations and transitions
- 📱 Fully responsive design
- 🔄 Multiple chat modes (General/Expert)
- ⚡ Quick reply suggestions

## Tech Stack

- Backend: Flask (Python)
- Frontend: Vanilla JavaScript, HTML5, CSS3
- UI Components: Bootstrap 5
- Icons: Font Awesome

## Required Dependencies

```
flask
flask-sqlalchemy
werkzeug
```

## Getting Started

1. Clone or download the project
2. Install dependencies:
```bash
pip install flask flask-sqlalchemy werkzeug
```
3. Run the application:
```bash
python main.py
```
4. Open your browser and navigate to `http://localhost:5000`

## Project Structure

```
.
├── static/
│   ├── css/
│   │   └── style.css
│   └── js/
│       ├── chat.js
│       ├── main.js
│       └── theme.js
├── templates/
│   ├── base.html
│   └── chat.html
├── app.py
└── main.py
```

## Features and Usage

1. **Chat Modes**
   - General Mode: For everyday conversations
   - Expert Mode: For specialized technical help

2. **Theme Support**
   - Toggle between light and dark themes
   - Theme preference is saved locally

3. **Quick Replies**
   - Predefined quick reply buttons for common queries
   - Helps users get started quickly

4. **Responsive Design**
   - Works seamlessly on desktop and mobile devices
   - Adaptive layout for different screen sizes