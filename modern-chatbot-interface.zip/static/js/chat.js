class ChatManager {
    constructor() {
        this.messageInput = document.getElementById('message-input');
        this.sendButton = document.getElementById('send-btn');
        this.chatMessages = document.getElementById('chat-messages');
        this.modeBtns = document.querySelectorAll('.mode-btn');
        this.quickReplies = document.querySelectorAll('.quick-reply-btn');
        this.currentMode = 'general';
        this.isTyping = false;

        // Debug logging
        console.log('ChatManager initialized');
        console.log('Message input found:', !!this.messageInput);
        console.log('Send button found:', !!this.sendButton);
        console.log('Chat messages container found:', !!this.chatMessages);

        this.init();
    }

    init() {
        if (!this.messageInput || !this.sendButton || !this.chatMessages) {
            console.error('Required elements not found');
            return;
        }

        this.sendButton.addEventListener('click', () => {
            console.log('Send button clicked');
            this.sendMessage();
        });

        this.messageInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                console.log('Enter key pressed');
                e.preventDefault();
                this.sendMessage();
            }
        });

        this.modeBtns.forEach(btn => {
            btn.addEventListener('click', () => this.switchMode(btn));
        });

        this.quickReplies.forEach(btn => {
            btn.addEventListener('click', (e) => this.handleQuickReply(e.target.textContent));
        });

        // Add welcome message
        this.addMessage('Welcome! I\'m your AI assistant. I can help you in two modes:\n• General: For everyday conversations\n• Expert: For specialized technical help\n\nChoose a mode to get started!', 'bot');
        console.log('ChatManager initialization completed');
    }

    async sendMessage() {
        const message = this.messageInput.value.trim();
        console.log('Attempting to send message:', message);
        if (!message || this.isTyping) return;

        this.addMessage(message, 'user');
        this.messageInput.value = '';
        this.messageInput.style.height = 'auto';
        await this.simulateResponse(message);
    }

    async simulateResponse(message) {
        this.isTyping = true;
        this.showTypingIndicator();

        try {
            const response = await fetch('/api/send_message', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    message: message,
                    mode: this.currentMode
                })
            });

            // Minimum typing time of 1 second for natural feel
            await new Promise(resolve => setTimeout(resolve, 1000));

            const data = await response.json();
            this.removeTypingIndicator();
            this.addMessage(data.response, 'bot');
        } catch (error) {
            console.error('Error:', error);
            this.removeTypingIndicator();
            this.addMessage('Sorry, I encountered an error. Please try again.', 'bot');
        }

        this.isTyping = false;
    }

    addMessage(content, type) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}`;
        messageDiv.innerHTML = `
            <div class="message-content">
                ${this.formatMessage(content)}
            </div>
        `;
        this.chatMessages.appendChild(messageDiv);

        // Ensure the chat container is scrolled to the bottom
        this.scrollToBottom();

        // Add a small delay to handle any dynamic content rendering
        setTimeout(() => this.scrollToBottom(), 100);
    }

    formatMessage(content) {
        // Convert URLs to clickable links
        return content.replace(
            /(https?:\/\/[^\s]+)/g,
            '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>'
        ).replace(/\n/g, '<br>');
    }

    showTypingIndicator() {
        const indicator = document.createElement('div');
        indicator.className = 'message bot typing-indicator';
        indicator.innerHTML = `
            <div class="message-content">
                <div class="typing-dots">
                    <span></span><span></span><span></span>
                </div>
            </div>
        `;
        this.chatMessages.appendChild(indicator);
        this.scrollToBottom();
    }

    removeTypingIndicator() {
        const indicator = this.chatMessages.querySelector('.typing-indicator');
        if (indicator) {
            indicator.remove();
            this.scrollToBottom();
        }
    }

    switchMode(btn) {
        if (this.isTyping) return;

        this.modeBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this.currentMode = btn.dataset.mode;

        const modeMessage = this.currentMode === 'expert'
            ? 'Switched to Expert mode. I\'ll provide more technical and detailed responses.'
            : 'Switched to General mode. I\'ll keep things simple and conversational.';

        this.addMessage(modeMessage, 'bot');
    }

    handleQuickReply(text) {
        if (!this.isTyping) {
            this.messageInput.value = text;
            this.sendMessage();
        }
    }

    scrollToBottom() {
        const chatContainer = this.chatMessages;
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }
}

// Ensure the ChatManager is initialized after DOM content is loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM content loaded, initializing ChatManager');
    window.chatManager = new ChatManager();
});