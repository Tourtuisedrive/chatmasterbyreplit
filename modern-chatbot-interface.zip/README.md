# Modern Chatbot Interface

A modern, responsive chatbot interface built with Flask and vanilla JavaScript. The application features a clean, intuitive design with support for both light and dark themes.

## Features

- 💬 Real-time chat interface
- 🌓 Light/Dark theme support
- 💨 Smooth animations and transitions
- 📱 Fully responsive design
- 🔄 Multiple chat modes (General/Expert)
- ⚡ Quick reply suggestions

## Tech Stack

- Backend: Flask (Python)
- Frontend: Vanilla JavaScript, HTML5, CSS3
- UI Components: Bootstrap 5
- Icons: Font Awesome

## Getting Started

1. Clone the repository
2. Install dependencies:
```bash
pip install -r requirements.txt
```
3. Run the application:
```bash
python main.py
```
4. Open your browser and navigate to `http://localhost:5000`

## Project Structure

```
.
├── static/
│   ├── css/
│   │   └── style.css
│   └── js/
│       ├── chat.js
│       ├── main.js
│       └── theme.js
├── templates/
│   ├── base.html
│   └── chat.html
├── app.py
└── main.py
```
